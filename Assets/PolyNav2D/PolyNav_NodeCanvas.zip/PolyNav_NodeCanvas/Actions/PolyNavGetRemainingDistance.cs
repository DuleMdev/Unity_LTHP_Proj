using UnityEngine;
using NodeCanvas.Variables;

namespace NodeCanvas.Actions{

	[Name("Get Remaining Distance")]
	[Category("PolyNav")]
	[AgentType(typeof(PolyNavAgent))]
	public class PolyNavGetRemainingDistance : ActionTask {

		public BBFloat saveAs = new BBFloat{blackboardOnly = true};

		protected override string info{
			get {return string.Format("Get path distance as {0}", saveAs);}
		}

		PolyNavAgent navAgent{
			get {return agent as PolyNavAgent;}
		}

		protected override void OnExecute(){
			saveAs.value = navAgent.remainingDistance;
			EndAction(true);
		}
	}
}